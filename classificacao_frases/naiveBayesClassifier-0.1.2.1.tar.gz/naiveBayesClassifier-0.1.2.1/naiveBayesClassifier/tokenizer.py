def tokenize(text):
    return text.lower().split(' ')