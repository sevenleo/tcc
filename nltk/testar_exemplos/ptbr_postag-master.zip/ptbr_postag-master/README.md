# ptbr_postag
Part-of-Speech tagging module for brazilian portuguese language
